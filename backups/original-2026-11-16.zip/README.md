# Phone preview

Open `index.html` in your browser. No install, server, or build is needed.

```text
index.html         Opens the phone preview
app/               The page shown inside the phone
  index.html       Your page's HTML
  src/
    styles.css     Your page's CSS
    main.js        Your page's JavaScript
phone/             The phone frame's styles and fonts
  styles.css
  fonts/
```

Work in `app/` for your page. Put its images and other assets in `app/assets/` when needed. The phone loads `app/index.html` in an iframe, with separate styles and internal scrolling. Its viewport is 402px wide.

Work in `phone/` to change the frame. The preview is 600px tall at 100% zoom. Zooming out centers it; zooming in allows scrolling. Short windows also scroll. Keep the fixed CSS scale so browser zoom works normally.

The dot folders are project support files:

- `.dev/` holds optional developer tools. Run `node .dev/check-browser.mjs` to check browser zoom and iframe behavior. It saves screenshots in ignored `.dev/artifacts/`.
- `.openai/` preserves this project's existing hosting connection. You do not need to edit it for local work.
- `.git/` stores version history.

Only for hosting, `node .dev/build.mjs` creates a fresh `dist/` copy. Local preview always uses the root `index.html`; generated files are not a second place to edit.
